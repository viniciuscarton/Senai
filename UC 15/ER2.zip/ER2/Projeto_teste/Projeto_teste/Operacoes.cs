﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_teste
{
    public static class Operacoes
    {
        public static double Somar(double pNum, double sNum)
        {
            return (pNum + sNum);
        }
    }
}
